// server.js
require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const twilio = require('twilio');
const WebSocket = require('ws');

const app = express();
app.use(bodyParser.urlencoded({ extended: false }));

// Twilio client
const client = twilio(
  process.env.TWILIO_ACCOUNT_SID,
  process.env.TWILIO_AUTH_TOKEN
);

// 🚀 API route to start a call
app.post('/call', async (req, res) => {
  try {
    const call = await client.calls.create({
      to: req.body.phone,
      from: process.env.TWILIO_PHONE_NUMBER,
      url: `${process.env.APP_BASE_URL}/voice`
    });
    res.json({ success: true, callSid: call.sid });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// 📞 Twilio hits this when call starts
app.post('/voice', (req, res) => {
  const twiml = new twilio.twiml.VoiceResponse();

  // Send caller’s audio to WebSocket
  twiml.connect().stream({
    url: `${process.env.APP_BASE_URL}/media-stream`
  });

  res.type('text/xml');
  res.send(twiml.toString());
});

// --- WebSocket Server for Media Streams ---
const wss = new WebSocket.Server({ noServer: true });

// Start HTTP server
app.server = app.listen(process.env.PORT || 3000, () => {
  console.log(`🚀 AI Calling App is running! Use POST /call to start a call.`);
});

// Upgrade HTTP → WebSocket
app.server.on('upgrade', (req, socket, head) => {
  if (req.url === '/media-stream') {
    wss.handleUpgrade(req, socket, head, (ws) => {
      wss.emit('connection', ws, req);
    });
  } else {
    socket.destroy();
  }
});

// Handle Twilio <-> OpenAI audio streaming
wss.on('connection', async (ws) => {
  console.log("🔊 New Twilio stream connected");

  // Connect to OpenAI Realtime API
  const aiWs = new WebSocket(
    "wss://api.openai.com/v1/realtime?model=gpt-4o-realtime-preview",
    {
      headers: {
        Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
        "OpenAI-Beta": "realtime=v1"
      }
    }
  );

  // aiWs.on('open', () => {
  //   console.log("🤖 Connected to OpenAI Realtime API");


  //   aiWs.send(JSON.stringify({
  //     type: "response.create",
  //     response: {
  //       modalities: ["audio"],
  //       voice: "verse",
  //       instructions: `
  //         You are a friendly AI call agent.
  //         As soon as the call starts, greet the caller warmly (like "Hello, this is Alex from our team!").
  //         Then ask for their name.
  //         After they answer, acknowledge it and ask one simple follow-up question:
  //         "What are you most interested in learning or exploring with us?"
  //         Keep the conversation natural and interactive.
  //       `
  //     }
  //   }));
  // });


  // ws.on('message', (msg) => {
  //   aiWs.send(msg);
  // });



  aiWs.on('open', () => {
  console.log("🤖 Connected to OpenAI Realtime API");

  // ✅ Auto-start AI agent flow
  aiWs.send(JSON.stringify({
    type: "response.create",
    response: {
      modalities: ["audio", "text"],   // <--- added text so we get transcripts
      voice: "verse",
      instructions: `
        You are a friendly AI call agent.
        As soon as the call starts, greet the caller warmly (like "Hello, this is Alex from our team!").
        Then ask for their name.
        After they answer, acknowledge it and ask one simple follow-up question:
        "What are you most interested in learning or exploring with us?"
        Keep the conversation natural and interactive.
        Provide transcripts of what the user says too.
      `
    }
  }));
});

// --- Log transcripts of caller responses ---
aiWs.on('message', (msg) => {
  const data = JSON.parse(msg.toString());

  // Check if AI recognized any text from caller
  if (data.type === "response.output_text.delta") {
    console.log("🗣️ Caller said:", data.delta);
  }

  // Forward everything back to Twilio (audio + responses)
  ws.send(msg);
});
  

  // Forward AI audio → caller
  aiWs.on('message', (msg) => {
    ws.send(msg);
  });

  ws.on('close', () => {
    console.log("❌ Twilio stream closed");
    aiWs.close();
  });
});
