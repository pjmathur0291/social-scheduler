<?php
/*
 * Cars member
 */
cars4rent_storage_set('single_style', 'single-cars');

get_template_part('single');
?>