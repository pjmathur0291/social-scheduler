// (function($){
	
// 	/**
// 	 * Immediate execution
// 	 */
// 	console.log();
	
// 	/**
// 	 * When DOM is ready
// 	 */
// 	$(document).ready(function(){
// 		if( $('html').attr('dir') == 'rtl' && $('body').hasClass('body_style_boxed')){
// 			$('[data-vc-full-width="true"]').each( function(i,v){
// 				$(this).css('right' , $(this).css('left') ).css( 'left' , 'auto');
// 				console.log(1);
// 			});
// 		}
// 	});
	
// 	/**
// 	 * When all content is loaded
// 	 */
// 	$(window).load(function(){
// 		if( $('html').attr('dir') == 'rtl' && $('body').hasClass('body_style_boxed')){
// 			$('[data-vc-full-width="true"]').each( function(i,v){
// 				$(this).css('right' , $(this).css('left') ).css( 'left' , 'auto');
// 				console.log(1);
// 			});
// 		}
// 	}); // window.load END
	
// })(jQuery);