<?php
/* Contact Form 7 support functions
------------------------------------------------------------------------------- */

// Theme init priorities:
// 9 - register other filters (for installer, etc.)
if (!function_exists('cars4rent_cf7_theme_setup9')) {
	add_action( 'after_setup_theme', 'cars4rent_cf7_theme_setup9', 9 );
	function cars4rent_cf7_theme_setup9() {

		if (cars4rent_exists_visual_composer()) {
			add_filter('wpcf7_autop_or_not', '__return_false');
			add_action('cars4rent_action_add_styles',		 				'cars4rent_cf7_scripts' );
		}
		
		if (is_admin()) {
			add_filter( 'cars4rent_filter_tgmpa_required_plugins',	'cars4rent_cf7_tgmpa_required_plugins' );
		}
	}
}

// Filter to add in the required plugins list
if ( !function_exists( 'cars4rent_cf7_tgmpa_required_plugins' ) ) {
	function cars4rent_cf7_tgmpa_required_plugins($list=array()) {
		if (cars4rent_storage_isset('required_plugins', 'contact-form-7')) {
			// CF7 plugin
			$list[] = array(
					'name' 		=> cars4rent_storage_get_array('required_plugins', 'contact-form-7'),
					'slug' 		=> 'contact-form-7',
					'required' 	=> false
			);
		}
		return $list;
	}
}

// Check if cf7 installed and activated
if ( !function_exists( 'cars4rent_exists_cf7' ) ) {
	function cars4rent_exists_cf7() {
		return class_exists('WPCF7') && class_exists('WPCF7_ContactForm');
	}
}

// Enqueue VC custom styles
if ( !function_exists( 'cars4rent_cf7_scripts' ) ) {
	function cars4rent_cf7_scripts() {
		if (file_exists(cars4rent_get_file_dir('css/plugin.contact-form-7.css')))
			wp_enqueue_style( 'cars4rent-contact-form-7-style',  cars4rent_get_file_url('css/plugin.contact-form-7.css'), array(), null );
	}
}
?>