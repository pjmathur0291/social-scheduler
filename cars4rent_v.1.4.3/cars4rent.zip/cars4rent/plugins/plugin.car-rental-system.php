<?php
	/* Car Rental System support functions
	------------------------------------------------------------------------------- */

// Theme init
if (!function_exists('cars4rent_car_rental_system_theme_setup')) {
	add_action( 'cars4rent_action_before_init_theme', 'cars4rent_car_rental_system_theme_setup',1 );
	function cars4rent_car_rental_system_theme_setup() {
		add_filter('cars4rent_filter_list_post_types', 			'cars4rent_car_rental_system_list_post_types', 10, 1);

		if (cars4rent_exists_quickcal()) {
			add_action('cars4rent_action_add_styles', 					'cars4rent_car_rental_system_frontend_scripts');
		}
	}
}

// Theme init priorities:
// 9 - register other filters (for installer, etc.)
	if (!function_exists('cars4rent_car_rental_system_theme_setup9')) {
		add_action( 'after_setup_theme', 'cars4rent_car_rental_system_theme_setup9', 9 );
		function cars4rent_car_rental_system_theme_setup9() {
			add_filter('cars4rent_filter_get_blog_type',			'cars4rent_car_rental_system_get_blog_type', 9, 2);
			add_filter('cars4rent_filter_get_blog_title',			'cars4rent_car_rental_system_get_blog_title', 9, 2);
		}
	}


// Enqueue custom styles
if ( !function_exists( 'cars4rent_car_rental_system_frontend_scripts' ) ) {
	function cars4rent_car_rental_system_frontend_scripts() {
		if (file_exists(cars4rent_get_file_dir('css/plugin.car-rental-system.css')))
			wp_enqueue_style( 'cars4rent-car-rental-style',  cars4rent_get_file_url('css/plugin.car-rental-system.css'), array(), null );
	}
}

// Check if car_rental_system installed and activated
	if ( !function_exists( 'cars4rent_exists_car_rental_system' ) ) {
		function cars4rent_exists_car_rental_system() {
			return class_exists('FleetManagement\CarRentalSystem');
		}
	}

// Filter to detect current page slug
	if ( !function_exists( 'cars4rent_car_rental_system_get_blog_type' ) ) {
		function cars4rent_car_rental_system_get_blog_type($page, $query=null) {
			if (!empty($page)) return $page;
			else if ($query && $query->get('post_type')=='car_rental_item' || get_query_var('post_type')=='car_rental_item')
				$page = $query && $query->is_single() || is_single() ? 'car_rental_item' : 'car_rental';
			else if ($query && $query->get('post_type')=='car_rental_page' || get_query_var('post_type')=='car_rental_page')
				$page = $query && $query->is_single() || is_single() ? 'car_rental_page' : 'car_rental';
			else if ($query && $query->get('post_type')=='car_rental_location' || get_query_var('post_type')=='car_rental_location')
				$page = $query && $query->is_single() || is_single() ? 'car_rental_location' : 'car_rental';
			return $page;
		}
	}

// Filter to detect current page title
	if ( !function_exists( 'cars4rent_car_rental_system_get_blog_title' ) ) {
		function cars4rent_car_rental_system_get_blog_title($title, $page) {
			if (!empty($title)) return $title;
			if ( cars4rent_strpos($page, 'car_rental')!==false ) {
				if ( $page == 'car_rental_item' || $page == 'car_rental_page' || $page == 'car_rental_location' ) {
					$title = cars4rent_get_post_title();
				} else {
					$title = esc_html__('All Cars', 'cars4rent');
				}
			}
			return $title;
		}
	}

// Add custom post type into list
if ( !function_exists( 'cars4rent_car_rental_system_list_post_types' ) ) {
	function cars4rent_car_rental_system_list_post_types($list) {
		$list = is_array($list) ? $list : array();
		$list['car_rental_item'] = esc_html__('Car Rental', 'cars4rent');
		return $list;
	}
}

?>