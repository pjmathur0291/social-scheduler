<?php
/*
 * Players item
 */
cars4rent_storage_set('single_style', 'single-players');

get_template_part('single');
?>