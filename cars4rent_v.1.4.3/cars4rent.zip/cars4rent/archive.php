<?php
/**
 * Blog archive
 */

get_template_part('blog');
?>