<?php
/**
 * The template for displaying Comments.
 *
 * The area of the page that contains both current comments
 * and the comment form. 
 */

/*
 * If the current post is protected by a password and
 * the visitor has not yet entered the password we will
 * return early without loading the comments.
 */
if ( post_password_required() )
	return;

if ( have_comments() || comments_open() ) {
	?>
	<section class="comments_wrap">
	<?php
	if ( have_comments() ) {
	?>
		<div id="comments" class="comments_list_wrap">
			<h2 class="section_title comments_list_title"><?php $post_comments = get_comments_number(); echo esc_html($post_comments); ?> <?php echo (1==$post_comments ? esc_html__('Comment', 'cars4rent') : esc_html__('Comments', 'cars4rent')); ?></h2>
			<ul class="comments_list">
				<?php
				wp_list_comments( array('callback'=>'cars4rent_output_single_comment') );
				?>
			</ul><!-- .comments_list -->
			<?php if ( !comments_open() && get_comments_number()!=0 && post_type_supports( get_post_type(), 'comments' ) ) { ?>
				<p class="comments_closed"><?php esc_html_e( 'Comments are closed.', 'cars4rent' ); ?></p>
			<?php }	?>
			<div class="comments_pagination"><?php paginate_comments_links(); ?></div>
		</div><!-- .comments_list_wrap -->
	<?php 
	}

	if ( comments_open() ) {
		?>
		<div class="comments_form_wrap">
			<h2 class="section_title comments_form_title"><?php esc_html_e('Add Comment', 'cars4rent'); ?></h2>
			<div class="comments_form">
				<?php
				$form_style = esc_attr(cars4rent_get_theme_option('input_hover'));
				$commenter = wp_get_current_commenter();
				$req = get_option( 'require_name_email' );
				$aria_req = ( $req ? ' aria-required="true"' : '' );
				$privacy_text = cars4rent_get_privacy_text();
				$cars4rent_comments_args = apply_filters(	'cars4rent_filter_comment_form_args', array(
						// class of the 'form' tag
						'class_form' => 'comment-form sc_input_hover_' . esc_attr($form_style),
						// change the id of send button
						'id_submit'=>'send_comment',
						// change the title of send button 
						'label_submit'=>esc_html__('Submit Comment', 'cars4rent'),
						// change the title of the reply section
						'title_reply'=>'',
						// remove "Logged in as"
						'logged_in_as' => '',
						// remove text before textarea
						'comment_notes_before' => '<p class="comments_notes">'.esc_html__('Your email address will not be published. Required fields are marked *', 'cars4rent').'</p>',
						// remove text after textarea
						'comment_notes_after' => '',
						// redefine your own textarea (the comment body)
						'fields'               => array(
						'author' => cars4rent_single_comments_field(
										array(
											'form_style'        => $form_style,
											'field_type'        => 'text',
											'field_req'         => true,
											'field_icon'        => 'icon-user',
											'field_value'       => isset($commenter['comment_author']) ? $commenter['comment_author'] : '',
											'field_name'        => 'author',
											'field_title'       => esc_attr__( 'Name', 'cars4rent' ),
											'field_placeholder' => esc_attr__( 'Name', 'cars4rent' ),
										)
								),
						'email'  => cars4rent_single_comments_field(
								 array(
									  'form_style'        => $form_style,
									  'field_type'        => 'text',
									  'field_req'         => $req,
									  'field_icon'        => 'icon-mail',
									  'field_value'       => isset( $cars4rent_commenter['comment_author_email'] ) ? $cars4rent_commenter['comment_author_email'] : '',
									  'field_name'        => 'email',
									  'field_title'       => esc_attr__( 'E-mail', 'cars4rent' ),
									  'field_placeholder' => esc_attr__( 'E-mail', 'cars4rent' ),
										)
									),
							),
						// redefine your own textarea (the comment body)
						'comment_field'        => cars4rent_single_comments_field(
								array(
									'form_style'        => $form_style,
									'field_type'        => 'textarea',
									'field_req'         => true,
									'field_icon'        => 'icon-feather',
									'field_value'       => '',
									'field_name'        => 'comment',
									'field_title'       => esc_attr__( 'Comment', 'cars4rent' ),
									'field_placeholder' => esc_attr__( 'Comment', 'cars4rent' ),
								)
						),
				 )
			);
			
				comment_form($cars4rent_comments_args);
				?>
			</div>
		</div><!-- /.comments_form_wrap -->
	<?php 
	}
	?>
	</section><!-- /.comments_wrap -->
<?php 
}
?>