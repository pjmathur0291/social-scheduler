<?php
/*
 * Matches item
 */
cars4rent_storage_set('single_style', 'single-matches');

get_template_part('single');
?>