<?php
/**
 * Child-Theme functions and definitions
 */
 
 function cars4rent_child_scripts() {
    wp_enqueue_style( 'cars4rent-parent-style', get_template_directory_uri(). '/style.css' );
}
add_action( 'wp_enqueue_scripts', 'cars4rent_child_scripts' );
 
 
?>